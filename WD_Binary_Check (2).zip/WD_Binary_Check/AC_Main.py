# -*- coding: utf-8 -*-
"""
Created on Mon Jun  2 11:02:06 2025

@author: tabbet_j
"""
from read_bin import main as rb
import numpy as np
import time as tt
import requests
import io
import pandas as pd
from matplotlib import pyplot as plt
from matplotlib.gridspec import GridSpec
from scipy import integrate as sint
import glob, os
from scipy.stats import gaussian_kde
from scipy.interpolate import make_smoothing_spline
 
from tkinter import * 
from matplotlib.figure import Figure 
from matplotlib.backends.backend_tkagg import (FigureCanvasTkAgg,  
NavigationToolbar2Tk) 

def ACheck(output, N):
    boff=75
    xoff1 = 10
    xoff2 = 30
    lt, wf, t,Nchan,scalers = output#,d1,d2,d3
    # global N_t
    N_t = len(lt)
    # print('Number of eN_t)
    cwf = [[] for _ in range(N)]
    cwft = [[] for _ in range(N)]
    cph = [[] for _ in range(N)]

    psdr = []
    tout = []
    phout = []

    for i in range(0, N_t, N):
        tout.append(t[i])
        for j in range(N):
            tempwf = np.array(wf[i+j])
            tempwft=np.array(lt[i+j])
            ref = np.mean(tempwf[xoff1:xoff2])

            postwf = tempwf[xoff2:]
            acmin = xoff2 + np.argmin(postwf)
            val = np.mean(tempwf[acmin-3:acmin+3])

            pkpk = ref - val
            phout.append(pkpk)

            hm = val + pkpk / 2
            ind_hm = acmin + np.argmin(np.abs(tempwf[acmin:] - hm))


            # base_start = tempwf[:xoff2]
            base_start=tempwf[acmin-boff:acmin]
            # base_mean = np.mean(base_start)
            # base_std = np.std(base_start)
            
            # above_thresh = np.where(np.abs(tempwf - base_mean) > 3 * base_std)[0]
            # ind_s = above_thresh[0] if len(above_thresh) > 0 else 0
            if pkpk>0.01:
                try:
                    ind_s=acmin-boff+np.argmax(np.cumsum(base_start))-3
                except ValueError:
                    boff=acmin
                    base_start=tempwf[acmin-boff:acmin]
                    ind_s=acmin-boff+np.argmax(np.cumsum(base_start))-3
            # 
                base_end = tempwf[-xoff2:]
                base_mean_end = np.mean(base_end)
                base_std_end = np.std(base_end)
                above_thresh_end = np.where(np.abs(tempwf - base_mean_end) > 1.5 * base_std_end)[0]
                ind_e = above_thresh_end[-1] if len(above_thresh_end) > 0 else len(tempwf) - 1
                
                if ind_s < ind_hm < ind_e:
                    int_offset=np.amax(tempwf[ind_s:ind_e])
                    q_s = sint.simpson(tempwf[ind_s:ind_hm]-int_offset,x=tempwft[ind_s:ind_hm])
                    q_t = sint.simpson(tempwf[ind_s:ind_e]-int_offset,x=tempwft[ind_s:ind_e])
                    psd = 1 - q_s / q_t
                    if abs(q_t)<abs(q_s):
                        psd=9999
                        # print(i,j,ind_s,ind_hm,ind_e,q_s/q_t)
                else:
                    psd = 9999
            else:
                psd=9999

            cwf[j].append(tempwf)
            cwft[j].append(tempwft)
            cph[j].append(pkpk)
            psdr.append(psd)

    return cwf,cwft, cph, tout, psdr, phout#,d1,d2,d3

def meshmake(x,y,axind,title):
    # x=dataout_c1[:,0]
    # y=dataout_c1[:,1]
    x=np.array(x)
    y=np.array(y)
    nbins=50
    k = gaussian_kde([x,y])
    xi, yi = np.mgrid[
        # downlimx:uplimx:nbins*1j,
        # downlim:uplim:nbins*1j
        # 0:1:nbins*1j,
        # 0:1:nbins*1j
        x.min():x.max():nbins*1j,
        y.min():y.max():nbins*1j
    ]
    zi = k(np.vstack([
        xi.flatten(),
        yi.flatten()
    ])).reshape(xi.shape)
    tempimg=axind.pcolormesh(xi, yi, zi,cmap='turbo')
    plt.colorbar(tempimg,ax=axind,label='Frequency density',orientation="horizontal", pad=0.2)
    # zvals.append(zi)

def scal_proc(scalers_A,Tzero,axind_0,axind_1,i,cbank,Tsmooth):
    scaler_diff=scalers_A[1:]-scalers_A[:-1]
    scaler_ind=np.array([0])
    scaler_ind=np.concatenate((scaler_ind,np.nonzero(scaler_diff)[0]+1))
    T_scalers=Tzero[scaler_ind]
    scaler_red=scalers_A[scaler_ind]
    scaler_hist=np.histogram(scaler_red,np.linspace(np.amin(scaler_red)-10,np.amax(scaler_red)+10,30))
    
    if len(T_scalers)!=1:
        spl2 = make_smoothing_spline(T_scalers,scaler_red,lam=10)
        axind_0.scatter(T_scalers,scaler_red,ec=cbank[i],fc='w',label='CH'+str(i)+' Scaler rate')
        axind_0.plot(Tsmooth,spl2(Tsmooth),linewidth=3,color=cbank[i],label='CH'+str(i))
        axind_1.plot(scaler_hist[0],scaler_hist[1][:-1],color=cbank[i],linewidth=1,drawstyle='steps-post',label='CH'+str(i))
        # print((np.amin(scaler_hist[1][:-1]),np.amax(scaler_hist[1][:-1])))
        
    return T_scalers,scaler_red,scaler_hist[1][:-1],scaler_hist[0]

def AC_mainfn(fname):
    # plt.ioff()
    s=tt.time()
    output=rb(fname)

    e=tt.time()
    num_events=len(output[0])
    print('Read binary process for',num_events,' events takes',round(e-s,2),'s')
    N=output[3]+1
    scalers_A=np.array(output[4]) #this is where the scalers are actually read and stored
    
    print('Now processing data...')
    proc_s=tt.time()
    (WF,WFt,PH,T,P,PHALL)=ACheck(output, N) #,d1,d2,d3
    
    k1,k2=[],[]
    for i in np.arange(0,len(P)):
        if P[i]!=9999:
            k1.append(PHALL[i])
            k2.append(P[i])
    
    # uplim=1#round(np.amax(k2)+np.amax(k2)*0.01,2)
    uplimx=1#round(np.amax(k1)+np.amax(k1)*0.01,2)
    # downlim=round(np.amin(k2)-np.amin(k2)*0.01,2)
    # downlimx=round(np.amin(k1)-np.amin(k1)*0.01,2)

    Tzero=np.array(T)-T[0]
    Tsmooth=np.linspace(0,Tzero[-1],50)
    Thist=np.histogram(Tzero,np.arange(0,Tzero[-1],1))
    # zvals=[]
    
    
    
    proc_e=tt.time()
    print('Data processing takes',round(proc_e-proc_s,2),'s')
    
    print('Now plotting...')
    cbank=['k','r','b','g',
           'darkgrey','firebrick','cyan','lime',
           'gold','purple','deeppink','peru']
    plot_s=tt.time()
    
    Tsmooth=np.linspace(0,Tzero[-1],200)

    fig,ax=plt.subplots(2,3,figsize=(12,9),tight_layout=True)#
    fig.suptitle(fname)
    
    spl = make_smoothing_spline(Thist[1][:-1],Thist[0],lam=10)
    ax[0,0].scatter(Thist[1][:-1],Thist[0],ec='k',fc='w',label='Save rate')
    ax[0,0].plot(Tsmooth,spl(Tsmooth),linewidth=3,color='k',label='Spline')
    meshmake(k1, k2, ax[1,2], 'PSD')
    for i in range(len(PH)):
        ad=WF[i][np.argmin(PH[i])]
        bd=WF[i][np.argmax(PH[i])]
        cd=WF[i][np.argsort(PH[i])[int(len(output[0])/N/2)]]
        ax[0,1].plot(1e9*WFt[i][np.argmin(PH[i])],ad,label='CH'+str(i)+' min',color=cbank[i],linewidth=0.8,linestyle=':')
        ax[0,1].plot(1e9*WFt[i][np.argmin(PH[i])],bd,label='CH'+str(i)+' max',color=cbank[i],linewidth=0.8,linestyle='--')
        ax[0,1].plot(1e9*WFt[i][np.argsort(PH[i])[int(len(output[0])/N/2)]],cd,label='CH'+str(i)+' median',color=cbank[i],linewidth=1.5)
        ax[0,2].hist(PH[i],np.arange(0,uplimx,0.01),fc='none',ec=cbank[i],linewidth=1,label='CH'+str(i))
        
        scaler_out=scal_proc(scalers_A[:,i], Tzero,ax[1,0],ax[1,1],i,cbank,Tsmooth)
    scaler_lims=ax[1,0].get_ylim()
    ax[1,1].set_ylim(scaler_lims[0],scaler_lims[1])

    
    ax[0,0].legend()
    ax[0,1].legend()
    ax[0,2].legend()    
    ax[1,0].legend()
    ax[1,1].legend()

    psd_lims=ax[1,2].get_xlim()
    ax[0,2].set_xlim(psd_lims[0],psd_lims[1])
    ax[0,2].set_yscale('log')
    
    
    ax[0,0].set_xlabel('Time (s)')
    ax[0,1].set_xlabel('Time (ns)')
    ax[0,2].set_xlabel('Pulse height (V)')
    ax[1,0].set_xlabel('Time (s)')
    ax[1,1].set_xlabel('Frequency')
    ax[1,2].set_xlabel('Pulse height (V)')
    
    ax[0,0].set_ylabel('Count rate (cps)')
    ax[0,1].set_ylabel('Voltage (V)')
    ax[0,2].set_ylabel('Frequency')
    ax[1,0].set_ylabel('Scaler rate (kHz)')
    ax[1,1].set_ylabel('Scaler rate (kHz)')
    ax[1,2].set_ylabel('PSD Parameter (arb.)')
    
    ax[0,0].set_title('(a) Event save rate')
    ax[0,1].set_title('(b) Waveform samples')
    ax[0,2].set_title('(c) Pulse height spectrum')
    ax[1,0].set_title('(d) Event scaler rates')
    ax[1,1].set_title('(e) Scaler rate distribution')
    ax[1,2].set_title('(f) Pulse shape discrimination')
    plt.savefig(fname+'.png',dpi=300)
    
    # plt.close()
    plot_e=tt.time()
    print('Plotting takes',round(plot_e-plot_s,2),'s')
    print('Total time',round(plot_e-s,2))
    print('---')
    # plt.ion()
    return fig
# plt.show()

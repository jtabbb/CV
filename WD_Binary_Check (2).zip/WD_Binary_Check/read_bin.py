import struct

def parse_fheader(data):
    return data[:3], data[3:4]

def parse_theader(data):
    return data[:4]

def parse_bheader(data):
    return data[:2], struct.unpack('H', data[2:4])[0]

def parse_eheader(data):
    unpacked = struct.unpack('IHHHHHHHH', data[4:24])
    return data[:4], unpacked

def parse_tcheader(data):
    return data[:2], struct.unpack('H', data[2:4])[0]

def parse_cheader(data):
    return data[:1], data[1:4]

def main(filename):
    print('Reading binary file:',filename)
    wfx = []
    wfy = []
    t = []
    escalers_out=[]
    Nout=0
    try:
        with open(filename, "rb") as f:
            # File header
            tag, version = parse_fheader(f.read(4))
            if tag != b'DRS' or version != b'8':
                return

            # Time header
            time_header = parse_theader(f.read(4))
            if time_header != b'TIME':
                return

            bin_width = [[[0.0 for _ in range(1024)] for _ in range(18)] for _ in range(1)]
            waveform = [[[0.0 for _ in range(1024)] for _ in range(18)] for _ in range(1)]
            time = [[[0.0 for _ in range(1024)] for _ in range(18)] for _ in range(1)]
            
            n_boards = 0
            while True:
                bh_data = f.read(4)
                if len(bh_data) < 4:
                    break
                bn, board_serial = parse_bheader(bh_data)
                if bn != b'B#':
                    f.seek(-4, 1)
                    break

                for chn in range(18):
                    ch_data = f.read(4)
                    ch_c, ch_cn = parse_cheader(ch_data)
                    if ch_c != b'C':
                        f.seek(-4, 1)
                        break
                    ch_index = (int(chr(ch_cn[1])) * 10) + int(chr(ch_cn[2]))
                    bin_width[n_boards][ch_index] = struct.unpack('1024f', f.read(1024 * 4))

                n_boards += 1

            while True:  # Process events
                eh_data = f.read(24)
                if len(eh_data) < 24:
                    break

                event_hdr, (
                    event_serial, year, month, day,
                    hour, minute, second, ms, v_range
                ) = parse_eheader(eh_data)
                
                for b in range(n_boards):
                    bh_data = f.read(4) #4
                    bn, board_serial = parse_bheader(bh_data)
                    if bn != b'B#':
                        return
                    
                    escalers=[]
                    escalers_out.append(escalers)
                    for chn in range(18):
                        ch_data = f.read(4)
                        ch_c, ch_cn = parse_cheader(ch_data)

                        if ch_c == b'E':
                            f.seek(-4, 1)
                            break

                        chn_index = (int(chr(ch_cn[1])) * 10) + int(chr(ch_cn[2]))

                        scalers =struct.unpack('I', f.read(4))[0]# f.read(4)  # scaler, unused
                        # print('scalers',scalers)
                        escalers.append(scalers)
                        tc_data = f.read(4)
                        tc_tag, trigger_cell = parse_tcheader(tc_data)
                        if tc_tag != b'T#':
                            return

                        voltage_raw = struct.unpack('1024H', f.read(1024 * 2))

                        bw = bin_width[b][chn_index]
                        wf = waveform[b][chn_index]
                        tm = time[b][chn_index]

                        cum_bw = [0.0] * 1025
                        for i in range(1, 1025):
                            cum_bw[i] = cum_bw[i - 1] + bw[(i - 1 + trigger_cell) % 1024]

                        for i in range(1024):
                            wf[i] = voltage_raw[i] / 65536.0 -0.9#+ v_range / 1000.0 - 0.5
                            
                            tm[i] = cum_bw[i]
                        wfx.append(tm[:])
                        wfy.append(wf[:])
                        tempt=(hour*3600)+(minute*60)+(second)+ms/1000
                        t.append(tempt)
                        
                        if chn>Nout:
                            Nout=chn
                        # print(chn,chn_index)
                    
    except Exception as e:
        # print(f"Error: {e}")
        print('...')
    return (wfx,wfy,t,Nout,escalers_out) #,v_range,voltage_raw,dummyl
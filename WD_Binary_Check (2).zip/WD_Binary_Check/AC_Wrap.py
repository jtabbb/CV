# -*- coding: utf-8 -*-
"""
Created on Mon Jun  2 10:48:32 2025

@author: tabbet_j
"""
import sys
from functools import partial
import os
import tkinter as tk
    
from matplotlib import pyplot as plt
# from read_bin import main as rb
from AC_Main import AC_mainfn as acm
from tkinter import filedialog, messagebox, ttk
import threading
# from tkinter import * 

import matplotlib
matplotlib.use('agg')
from matplotlib.backends.backend_tkagg import (FigureCanvasTkAgg,  
NavigationToolbar2Tk) 

# from ttkthemes import ThemedTk


class RedirectText:
    def __init__(self, text_widget):
        self.output = text_widget

    def write(self, string):
        self.output.insert(tk.END, string)
        self.output.see(tk.END)  # Auto-scroll

    def flush(self):
        pass  # Needed for file-like compatibility

canvas = None


def run_processing(filename):
    # print(f"Processing file: {filename}")
    fig1 = acm(filename)  # This runs in a thread now

    def draw_plot():
        global canvas
        if canvas is not None:
            canvas.get_tk_widget().pack_forget()
            canvas.get_tk_widget().destroy()
        canvas = FigureCanvasTkAgg(fig1, master=window)
        canvas.draw()
        canvas.get_tk_widget().pack()

    window.after(0, draw_plot)  # Schedule GUI update on main thread

def get_selected_file_name(file_menu):
    filename = file_menu.get()
    thread = threading.Thread(target=run_processing, args=(filename,))
    thread.start()

folder = os.getcwd()
filelist = []

for file_name in sorted(os.listdir(folder)):
    if file_name.endswith('.bin'):
        file_path = os.path.join(folder, file_name)
        filelist.append(file_name)

def changedd():
    print('Current files in directory:',len(filelist))
    temp_files=[]
    for file_name in sorted(os.listdir(folder)):
        if file_name.endswith('.bin'):
            temp_files.append(file_name)
    for i in temp_files:
        if i in filelist:
            next
        if i not in filelist:
            filelist.append(i)
    for i in filelist:
        if i not in temp_files:
            filelist.remove(i)
    print('Number of files found:',len(filelist))    
    

window = tk.Tk() 
window.geometry('1900x950')
window.title('WDB Binary File Check')

window.configure(background='white')
optmenu = ttk.Combobox(window, values=filelist, state='readonly',postcommand=lambda: optmenu.configure(values=filelist))
optmenu.pack(fill='x')
optmenu.set('Select file to process')

terminal_frame = tk.Frame(window)
terminal_frame.pack(side=tk.RIGHT, anchor='s', fill='both', expand=False)

terminal_label = tk.Label(terminal_frame, text="Terminal Output:")
terminal_label.pack(anchor='w')

terminal_output = tk.Text(terminal_frame, height=5, width=60, bg='black', fg='white')
terminal_output.pack(fill='both', expand=True)

# Redirect stdout/stderr
sys.stdout = RedirectText(terminal_output)
sys.stderr = RedirectText(terminal_output)

# button_select = tk.Button(window, text="Process\n File",
#                           width=20,
#                           height=2,
#                           compound=tk.CENTER,
#                           command=partial(get_selected_file_name, optmenu))

# button_select.pack(padx=5)#side=tk.LEFT,


# button_select2 = tk.Button(window, text="Update\n Files",
#                           width=20,
#                           height=2,
#                           compound=tk.CENTER,
#                           command=partial(changedd))

# button_select2.pack(padx=5)#side=tk.LEFT

button_frame = tk.Frame(window, bg='white')
button_frame.pack(side=tk.LEFT, anchor='nw')#, padx=10, pady=10

button_select = tk.Button(button_frame, text="Process\nFile",
                          width=20,
                          height=2,
                          compound=tk.CENTER,
                          command=partial(get_selected_file_name, optmenu))
button_select.pack(side=tk.TOP, padx=5,pady=5)

button_select2 = tk.Button(button_frame, text="Update\nFiles",
                           width=20,
                           height=2,
                           compound=tk.CENTER,
                           command=partial(changedd))
button_select2.pack(side=tk.TOP, padx=5,pady=5)

window.mainloop()